from pydantic import BaseModel
class Candidate(BaseModel):
    nom:str
