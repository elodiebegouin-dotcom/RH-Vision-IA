from fastapi import FastAPI
app=FastAPI(title="RH Vision IA")
@app.get("/")
def root(): return {"status":"ok"}
