def score_candidate(data):
    return {"score":85}
